import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AlumnosCard } from './alumnos-card';

describe('AlumnosCard', () => {
  let component: AlumnosCard;
  let fixture: ComponentFixture<AlumnosCard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AlumnosCard],
    }).compileComponents();

    fixture = TestBed.createComponent(AlumnosCard);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
