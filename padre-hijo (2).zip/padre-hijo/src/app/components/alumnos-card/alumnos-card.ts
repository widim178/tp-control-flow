import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Alumno } from '../../modules/alumnos-card/alumnos-card';

@Component({
  imports: [],
  selector: 'app-alumnos-card',
  styleUrl: './alumnos-card.css',
  templateUrl: './alumnos-card.html',
})
export class AlumnosCard {
  @Input() alumno!: Alumno;
  @Output() seleccionado = new EventEmitter<Alumno>();

  @Output() aprobacionCambiada = new EventEmitter<{ alumno: Alumno; aprobado: boolean }>();

  onSeleccionar() {
    this.seleccionado.emit(this.alumno);
  }

  onToggleAprobado() {
    this.alumno.aprobado = !this.alumno.aprobado;
    this.aprobacionCambiada.emit({ 
    alumno: this.alumno,
    aprobado: this.alumno.aprobado 
  });
  }



}


