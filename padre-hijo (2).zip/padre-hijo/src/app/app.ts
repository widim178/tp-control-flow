import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AlumnosCard } from './components/alumnos-card/alumnos-card';
import { Alumno } from './modules/alumnos-card/alumnos-card';

@Component({
  imports: [RouterOutlet, AlumnosCard],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  alumnos: Alumno[] = [
  {id: 1, nombre: 'Juan', edad: 20, aprobado: true},
  {id: 2, nombre: 'María', edad: 22, aprobado: false},
  {id: 3, nombre: 'Pedro', edad: 21, aprobado: true},
  ];
}

alumnoSeleccionado: Alumno | null = null;
